package pl.wit.kolokwium1.types;

public class MotorcycleType extends AbstractVehicleType
{

	@Override
	public Integer getVehicleTypeId() {
		return null;
	}

	@Override
	public String getVehicleTypeName() {
		return null;
	}

}
