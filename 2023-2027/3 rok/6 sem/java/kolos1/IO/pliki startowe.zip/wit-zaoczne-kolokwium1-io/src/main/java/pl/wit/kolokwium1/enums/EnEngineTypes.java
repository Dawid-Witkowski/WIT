package pl.wit.kolokwium1.enums;

public enum EnEngineTypes {
	
}
