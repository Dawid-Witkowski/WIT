package pl.wit.kolokwium1;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class VehiclesDatabaseTest {
	private VehiclesDatabase vehDb = null;
	
	@BeforeEach
	public void setUp() {
		vehDb = new VehiclesDatabase();
	}

	@Test
	public void dbSearchAllTest() {
		
		
	}
	

	@Test
	public void dbSearchBodyTypeTest() {
		
	}

	
}
