import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class zad63 {
    /*
    Uzupełnij implementację metody "searchElement" pod komentarzem "Dodaj implementację".
    Metoda ma zwracać index elementu listy "myList" wyszukanego z użyciem wyszukiwania binarnego dla wartości "element_4".
    Jednocześnie nie może zostać zmieniona kolejność elementów listy zdefiniowanej w klasie.
    Do implementacji należy użyć klasy "Collections" oraz metody "binarySearch".

     */
    public class Main {
        private List<String> myList = new ArrayList<>();
        public Main() {
            myList.add("element_1");
            myList.add("element_7");
            myList.add("element_3");
            myList.add("element_5");
            myList.add("element_4");
            myList.add("element_6");
            myList.add("element_2");
        }
        public String toString() {
            return String.valueOf(searchElement());
        }

        public int searchElement() {
            int index = 0;

            //Dodaj implementację


            return index;
        }


        public void main( String[] args )
        {
            Main main = new Main();

            System.out.println(main.toString());
            System.out.println(main.getMyListSize());
            System.out.println(main.getMyListElement(0));
            System.out.println(main.getMyListElement(3));
            System.out.println(main.getMyListElement(6));
        }

        public int getMyListSize(){
            return myList.size();
        }

        public String getMyListElement(int index){
            if(index>=0 && index< myList.size())
                return myList.get(index);
            else
                return null;
        }
    }
}
