public class zad72 {
    /*
    Uzupełnij implementację dwóch konstruktorów klasy "Question2" pod komentarzem "Dodaj implementację" (w 2 miejscach).

    Konstruktor prywatny ma inicjalizować zmienne dotyczące imienia i nazwiska.
    Natomiast konstruktor publiczny ma wywoływać konstruktor prywatny
    a następnie zainicjalizować zmienne "age" oraz "education".  Tablica ma otrzymać rozmiar zero.
     */
    public class Main {
        public Question2 q2 = null;
        public class Question2{

            private int age;
            private String firstName=null;
            private String lastName=null;
            private String[] education = null;

            private Question2(String firstName,String lastName) {
                //***Dodaj implementację***


            }
            public Question2(int age, String firstName,String lastName) {
                //***Dodaj implementację***

            }

            public int getAge() {
                return age;
            }
            public String getFirstName() {
                return firstName;
            }
            public String getLastName() {
                return lastName;
            }
            public String[] getEducation() {
                return education;
            }
        }

        public Main() {
            q2 = new Question2(23,"Ula","Psiarska");
        }

        public void main(String[] args) {
            Main main = new Main();
            System.out.println(main.q2.getAge());
            System.out.println(main.q2.getFirstName());
            System.out.println(main.q2.getLastName());
            System.out.println(main.q2.getEducation().length);

        }
    }
}
