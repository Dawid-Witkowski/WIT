import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
public class zad70 {
    /*
    Uzupełnij implementację metody "getOnlyOddItems" pod komentarzem "Dodaj implementację".
    Metoda ma zwracać przefiltrowaną listę tylko elementów zawierających na końcu  nieparzystą liczbę.
    Implementacja ma być wykonana z użyciem API strumieni i operacji filtracji,
    a następnie tworzenia kolekcji typu lista.
     */
    public class Main {
        KolokwiumPyt2 kp2 = null;
        public Main() {
            kp2 = new KolokwiumPyt2();
        }
        public class KolokwiumPyt2 {
            private Collection<String> collection = null;


            public List<String> getOnlyOddItems(){
                List<String> newList = null;
                //Dodaj implementację

                return newList;
            }



            public KolokwiumPyt2() {
                this.collection = new ArrayList<String>();
                for(int i=0;i<1000;i++) {
                    collection.add("element_"+((i+1)%100));
                }
            }


            public String toString() {
                StringBuilder sb = new StringBuilder();
                List<String> lstTest= getOnlyOddItems();
                if(lstTest==null)
                    lstTest= Collections.emptyList();
                sb.append("size=").append(Integer.toString(lstTest.size())).append("\n");
                if(lstTest.size()>0)
                    sb.append("first=").append(lstTest.get(0)).append("\n");
                if(lstTest.size()>0)
                    sb.append("last=").append(lstTest.get(lstTest.size()-1)).append("\n");
                return sb.toString();
            }
        }

        public String toString() {
            return kp2.toString();
        }
        public void main( String[] args )
        {
            Main main = new Main();
            System.out.println(main.toString());
        }
    }
}
