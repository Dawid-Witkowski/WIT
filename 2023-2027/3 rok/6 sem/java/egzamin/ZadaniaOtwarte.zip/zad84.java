public class zad84 {
    /*
    Uzupełnij implementację stałych wyliczeniowych dla klasy reprezentującej kwartały roku pod komentarzem
    "Dodaj implementację". Stałe zdefiniuj wielkimi literami  jako: Q1,Q2,Q3,Q4.
    Dodatkowo z każdą stałą trzeba przechować wartość o nazwie "id" typu "int",

    która ma być przypisana do odpowiednich stałych jako: 1,2,3,4. Zdefiniuj niezbędną zmienną, konstruktor oraz getter.
     */
    enum EnQuarters{
//***Dodaj implementację***


    }
    public class Main {


        public void printToConsole() {
            for(EnQuarters et:EnQuarters.values())
                System.out.println(et.name().concat("(").concat(String.valueOf(et.getId()).concat(")").toString()));
        }
        public static void main(String[] args) {
            Main main = new Main();
            main.printToConsole();
            System.out.println(EnQuarters.values().length);
        }
    }
}
