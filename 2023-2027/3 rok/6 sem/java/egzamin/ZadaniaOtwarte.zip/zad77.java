import java.util.Arrays;
public class zad77 {
    /*
    Uzupełnij implementację metody "setCarsValues" pod komentarzem "Dodaj implementację".
    Metoda ta ma inicjalizować zmienną "cars" jako tablicę 5 elementową oraz ma wstawić do niej następujące wartości
     w podanej kolejności rozpoczynając od indeksu "0":

Porsche, Audi, Fiat, Opel, Mazda
     */
    public class Main {
        private String cars[];
        public void setCarsValues() {
            //***Dodaj implementację***

        }
        public String[] getCars() {
            return cars;
        }


        public void main(String[] args) {
            Main main = new Main();
            main.setCarsValues();
            Arrays.stream(main.getCars()).forEach((n)->System.out.println(n.concat(", ")));
            System.out.println(main.getCars().length);
        }
    }
}
