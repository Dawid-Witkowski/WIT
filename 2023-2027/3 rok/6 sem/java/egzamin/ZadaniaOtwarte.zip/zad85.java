public class zad85 {
    /*
    Uzupełnij implementację metody "setId" pod komentarzem "Dodaj implementację".
    Metoda ma w sposób bezpieczny dla wielowątkowości dodawać do aktualnej wartości zmiennej "id" obiektu "ref" wartość
    przekazanego parametru "i";

    Można jedynie zmieniać "środek" metody bez zmiany aktualnej deklaracji.
     */
    public static int id =0;
    public class Main {


        public class MyThread extends Thread {
            private Main ref;
            public MyThread(String threadName, Main ref) {
                super(threadName);
                this.ref = ref;
                System.out.println(getName());
            }

            private void setId(int i) {
//Dodaj implementację


            }

            public void run() {

                for (int i = 0; i < 5; i++) {
                    setId(i);
                    try {
                        sleep(100);
                    } catch (InterruptedException e) {
// TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }
        }
        public void startThreads() {
            MyThread t1 = new MyThread("1",this);
            MyThread t2 = new MyThread("2",this);
            MyThread t3 = new MyThread("3",this);

            t1.start();
            t2.start();
            t3.start();
            try {
                t1.join();
                t2.join();
                t3.join();
            } catch (InterruptedException e) {
// TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        public void toConsole() {
            System.out.println("id=".concat(Integer.toString(id)));
        }

        public void main( String[] args )
        {
            Main main = new Main();
            main.startThreads();
            main.toConsole();
        }
    }
}
