import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
public class zad75 {
    /*
    Uzupełnij deklarację zmiennych w klasie Main pod komentarzem
    "Dodaj deklarację" definiując egzekutor o nazwie "es" i inicjując go jako ustalona pula 1 elementowa.

    Następnie uzupełnij implementację metody "startThreads" pod komentarzem "Dodaj implementację".
    Należy dopisać kod dodający wątki do puli zdefiniowanej uprzednio.

    Następnie należy zamknąć pulę wątków i ustawić czas oczekiwania na zamknięcie na 1 minutę.

    Można jedynie zmieniać "środek" metody bez zmiany aktualnej deklaracji.
     */
    public class Main {
        private List<String> toConsole = new ArrayList<>();
        //Dodaj deklarację

        public synchronized void  addToConsole(String item) {
            toConsole.add(item);
        }
        public class MyThread extends Thread {
            private Main ref=null;
            public MyThread(String threadName,Main ref) {
                super(threadName);
                this.ref=ref;
                ref.addToConsole(getName());
            }



            public void run() {
                for (int i = 0; i < 5; i++) {
                    try {
                        ref.addToConsole("Thread=".concat(getName()).concat(",i=").concat(Integer.toString(i)));
                        sleep(100);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }
        }
        public void startThreads() {
            MyThread t1 = new MyThread("1",this);
            MyThread t2 = new MyThread("2",this);
            MyThread t3 = new MyThread("3",this);
            MyThread t4 = new MyThread("4",this);
            MyThread t5 = new MyThread("5",this);

            //Dodaj implementację

        }

        public void toConsole() {
            toConsole.forEach((n)->System.out.println(n));
        }

        public void main( String[] args )
        {
            Main main = new Main();
            main.startThreads();
            main.toConsole();
        }
    }
}
