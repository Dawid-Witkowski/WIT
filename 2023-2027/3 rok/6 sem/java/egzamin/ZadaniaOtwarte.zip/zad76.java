import java.util.LinkedHashMap;
import java.util.Map;
public class zad76 {
    /*
    Uzupełnij deklarację oraz implementację metody "addMark" pod komentarzem "Dodaj implementację".
    Metoda ma zezwalać na generowanie wyjątków klasy "MarkException".

Ponadto jeśli przekazane parametry metody są poprawne (subject nie jest null oraz nie jest pustym łańcuchem znaków,
natomiast mark jest dodatnie) to ma dodawać parę postaci "(subject,mark)" do mapy.
W przeciwnym wypadku metoda ma wygenerować wyjątek klasy MarkException informujący o błędnych parametrach.
     */
    public class Main {
        private Map<String,Integer> mapMarks = new LinkedHashMap<>();

        public class MarkException extends Exception{
            public MarkException(String msg) {
                System.out.println("EXCEPTION");
            }
        }
        //***Dodaj implementację***
        public void addMark(String subject, int mark){


        }


        public void main(String[] args) {
            Main main = new Main();
            try {
                main.addMark("matematyka", 5);
            } catch (MarkException e) {
                // TODO Auto-generated catch block
            }
            try {
                main.addMark("fizyka", 4);
            } catch (MarkException e) {
            }
            try {
                main.addMark("", 3);
            } catch (MarkException e) {

            }
            try {
                main.addMark(null, 2);
            } catch (MarkException e) {
            }
            try {
                main.addMark("chemia", -2);
            } catch (MarkException e) {
            }
            main.getMapMarks().keySet().stream().forEach((key) ->System.out.println(key.concat(":").concat(String.valueOf(main.getMapMarks().get(key)))));

        }
        public Map<String, Integer> getMapMarks() {
            return mapMarks;
        }
    }
}
