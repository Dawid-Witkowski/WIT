import java.util.Arrays;
public class zad71 {
    /*
    Uzupełnij implementację metody "toString" pod komentarzem "Dodaj implementację".

Metoda ma wypisywać w oddzielnych wierszach nazwę zmiennej, następnie znak "=" bez spacji przed znakiem
oraz bez spacji po znaku "=", a następnie wartość danej zmiennej.
Kolejność zmiennych ma być zgodna z deklaracją zmiennych w klasie.
Na końcu ostatniego wiersza ma nie być znaku końca linii.
Do obsługi wypisania wartości tablicy użyj odpowiedniej metody z klasy Arrays.
     */
    public class Main {
        public Question8 q8 = null;
        public class Question8{
            private int age;
            private String firstName=null;
            private String lastName=null;
            private String[] education = null;


            public int getAge() {
                return age;
            }
            public String getFirstName() {
                return firstName;
            }
            public String getLastName() {
                return lastName;
            }
            public String[] getEducation() {
                return education;
            }
            public void setAge(int age) {
                this.age = age;
            }
            public void setFirstName(String firstName) {
                this.firstName = firstName;
            }
            public void setLastName(String lastName) {
                this.lastName = lastName;
            }
            public void setEducation(String[] education) {
                this.education = education;
            }


            public String toString() {
                //***Dodaj implementację***


            }
        }

        public Main() {
            q8 = new Question8();//21,"Ala","Kotarska");
            q8.setAge(30);
            q8.setFirstName("Zuza");
            q8.setLastName("Kowalska");
            q8.setEducation("mgr farmacji,mgr chemii".split(","));
        }

        public void main(String[] args) {
            Main main = new Main();
            System.out.println(main.q8.toString());

        }
    }
}
