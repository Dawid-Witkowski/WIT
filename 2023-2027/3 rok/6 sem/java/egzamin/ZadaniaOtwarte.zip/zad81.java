import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class zad81 {
    /*
    Uzupełnij implementację metody "getSorted" pod komentarzem "Dodaj implementację".
    Należy dopisać kod który posortuje elementy listy "list" w następujący sposób: po nazwisku malejąco,
    następnie po imieniu pierwszym malejąco, po czym po imieniu drugim rosnąco.
    Można jedynie zmieniać "środek" metody bez zmiany aktualnej deklaracji.

     */
    public class Main {
        List<String> list = new ArrayList<String>();

        private void prepareList() {
            list.add("Jan Tomasz Kowalski");
            list.add("Feliks Juliusz Nowak");
            list.add("Monika Aleksandra Nowakowska");
            list.add("Zuzanna Marta Kowalik");
            list.add("Krystyna Anna Chodakowska");
            list.add("Mateusz Maciej Gągała");
            list.add("Albert Mateusz Gągała");
            list.add("Daniel Albert Gągała");
            list.add("Martyna Mirosława Wędzikowska");
            list.add("Monika Martyna Wędzikowska");
            list.add("Monika Anna Wędzikowska");
            System.out.println(list.toString());
            System.out.println("-------------------");
        }

        public List<String> getSorted(){
            prepareList();
            //Dodaj implementację


            /////////////////////////////////////////////
            System.out.println(list.toString());
            return list;
        }

        public void main( String[] args )
        {
            Main main = new Main();
            main.getSorted();

        }
    }
}
