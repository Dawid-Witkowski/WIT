import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;
public class zad68 {
    /*
    Uzupełnij implementację metody "getTreeSet" pod komentarzem "Dodaj implementację".
    Metoda ma zwracać zbiór (TreeSet) składający się tylko z wyrazów kolekcji "list",
    które zawierają literę "a" (mała litera "a").
    Implementacja ma być wykonana z użyciem API strumieni i operacji filtracji,
    a następnie tworzenia kolekcji typu TreeSet.
     */
    public class Main {
        private List<String> list = null;
        public Main() {

            String text = "Ala ma kota a kot ma Alę";
            list = Arrays.asList(text.trim().split("[ ,.]"));
        }
        public TreeSet<String> getTreeSet() {
            TreeSet<String> treeSet = null;
            // Dodaj implementację

            return treeSet;
        }

        public void main(String[] args) {
            Main main = new Main();
            TreeSet<String> ts = main.getTreeSet();
            ts.stream().forEach((n)->System.out.println(n.concat(", ")));

        }
    }
}
