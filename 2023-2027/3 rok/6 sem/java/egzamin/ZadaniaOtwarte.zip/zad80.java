import java.util.LinkedHashMap;
import java.util.Map;
public class zad80 {
    /*
    Uzupełnij implementację metody "mapToString" pod komentarzem "Dodaj implementację".
    Metoda ma zbudować łańcuch znaków w następującej postaci: dla wszystkich par mapy w oddzielnych wierszach
    ma pojawić się wartość klucza, następnie ":" (bez spacji przed lub po) a następnie wartość powiązana z kluczem.
     */
    public class Main {
        private Map<Integer,String> mapPersons = new LinkedHashMap<>();
        public Map<Integer, String> getMapPersons() {
            return mapPersons;
        }
        public void setMapPersons(Map<Integer, String> mapPersons) {
            this.mapPersons = mapPersons;
        }


        public String mapToString() {
            StringBuilder sb = new StringBuilder();
            //***Dodaj implementację***


            return sb.toString();
        }

        public void main(String[] args) {
            Main main = new Main();
            main.getMapPersons().put(1, "Kowalski Jan");
            main.getMapPersons().put(2, "Nowak Jan");
            main.getMapPersons().put(3, "Nowak Janina");
            main.getMapPersons().put(1, "Nowakowska Janina");
            System.out.println(main.mapToString());
        }

    }
}
