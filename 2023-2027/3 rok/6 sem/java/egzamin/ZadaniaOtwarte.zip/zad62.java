import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class zad62 {
    /*
    Uzupełnij implementację komparatora pod komentarzem "Dodaj implementację".
    Komparator ma umożliwić sortowanie elementów zdefiniowanej listy po nazwisku rosnąco.

UWAGA: nie można modyfikować żadnych innych elementów klasy.

UWAGA2: Kod musi być zgodny z JAVA 1.8

UWAGA3: Kod należy edytować w Insperze (nie kopiować do inspery).

UWAGA4: Po zakończeniu wpisywania treści odpowiedzi należy skompilować kod (przycisk u dołu "KOD TESTU")
     */
    public class Main {
        private List<String> myList = new ArrayList<>();
        public Main() {
            myList.add("Ala Nowakowska");
            myList.add("Jan Kowalewski");
            myList.add("Ula Błędowska");
            myList.add("Iza Błędowska");
            myList.add("Jan Nowakowski");
        }
        protected Comparator<String> sortBySurname = (a,b) -> {
// Dodaj implementację

        };
        public String toString() {
            String test ="";
            sortBySurname = sortBySurname.thenComparing(Comparator.naturalOrder());
            Collections.sort(myList,sortBySurname);
            test = myList.toString();
            return test;
        }

        public void main( String[] args )
        {
            Main main = new Main();

            System.out.println(main.toString());
            System.out.println(main.getMyListSize());
            System.out.println(main.getMyListElement(0));
            System.out.println(main.getMyListElement(1));
            System.out.println(main.getMyListElement(2));
        }

        public int getMyListSize(){
            return myList.size();
        }

        public String getMyListElement(int index){
            if(index>=0 && index< myList.size())
                return myList.get(index);
            else
                return null;
        }
    }
}
