
public class zad64 {
    /*
    W klasie "Truck" wykonaj przesłonięcie metody "getType" pod komentarzem "Dodaj implementację".
    Nowa implementacja ma zwracać stałą wyliczeniową "truck".
     */

    enum EnVehicleType{
        car, truck, noType
    }
    public class Main {
        public Vehicle veh = new Truck();


        public class Vehicle{
            public EnVehicleType getType() {
                return  EnVehicleType.noType;
            }
        }

        public class Truck extends Vehicle{
            //***Dodaj implementację***

        }

        public void main(String[] args) {
            Main main = new Main();
            System.out.println(main.veh.getType());

        }
    }
}
