import java.util.ArrayList;
import java.util.List;
public class zad89 {
    /*
    Uzupełnij implementację metody "toString" pod komentarzem "Dodaj implementację".
    Metoda ma zwracać w jednym wierszu kolejne elementy listy oddzielone przecinkiem i spacją pod warunkiem,
    występowania kolejnego elementu. Dla ostatniego elementu listy przecinek i spacja nie ma być dodawany.
    Implementacja ma być zrobiona z użyciem API strumieni i operacji redukcji.
     */
    public class Main {
        private List<String> myList = new ArrayList<>();
        public Main() {
            myList.add("element_1");
            myList.add("element_2");
            myList.add("element_3");
            myList.add("element_4");
            myList.add("element_5");
            myList.add("element_6");
            myList.add("element_7");
        }
        public String toString() {
            String test ="";
            // Dodaj implementację

            return test;
        }

        public void main( String[] args )
        {
            Main main = new Main();

            System.out.println(main.toString());
            System.out.println(main.getMyListSize());
            System.out.println(main.getMyListElement(0));
            System.out.println(main.getMyListElement(3));
            System.out.println(main.getMyListElement(6));
        }

        public int getMyListSize(){
            return myList.size();
        }

        public String getMyListElement(int index){
            if(index>=0 && index< myList.size())
                return myList.get(index);
            else
                return null;
        }
    }
}
