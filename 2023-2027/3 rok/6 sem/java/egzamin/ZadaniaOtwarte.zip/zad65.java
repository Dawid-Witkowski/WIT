import java.util.function.Function;
public class zad65 {
    /*
    Uzupełnij implementację metody "assignBody" pod komentarzem "Dodaj implementację".
    Metoda ma przypisać do zmiennej interfejsu funkcyjnego zadeklarowanej w klasie,
    referencję do metody z klasy String o nazwie "valueOf".
     */
    public class Main {
        private Function<Integer, String> test = null;

        public void assignBody() {
            // Dodaj implementację


        }
        public void main(String[] args) {
            Main main = new Main();
            main.assignBody();
            main.printToConsole(123);
            main.printToConsole(987);
            main.printToConsole(777);
        }

        public void printToConsole(Integer value) {
            System.out.println(test.apply(value));
        }
    }
}
