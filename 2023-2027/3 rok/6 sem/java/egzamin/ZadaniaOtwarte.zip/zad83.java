import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class zad83 {
    /*
    Uzupełnij implementację metody "startThreads" pod komentarzem "Dodaj implementację".
    Należy dopisać kod z użyciem metody "isAlive" zapewniający oczekiwanie głównego wątku aplikacji na
    zakończenie pracy wszystkich wątków pochodnych występujących w tej metodzie.

    Można jedynie zmieniać "środek" metody bez zmiany aktualnej deklaracji.
     */
    public class Main {
        private List<String> toConsole = new ArrayList<>();

        public synchronized void  addToConsole(String item) {
            toConsole.add(item);
        }
        public class MyThread extends Thread {
            private Main ref=null;
            public MyThread(String threadName,Main ref) {
                super(threadName);
                this.ref=ref;
                ref.addToConsole(getName());
            }



            public void run() {
                for (int i = 0; i < 5; i++) {
                    try {
                        ref.addToConsole("Thread=".concat(getName()).concat(",i=").concat(Integer.toString(i)));
                        sleep(100);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

            }
        }
        public void startThreads() {
            MyThread t1 = new MyThread("1",this);
            MyThread t2 = new MyThread("2",this);
            MyThread t3 = new MyThread("3",this);

            t1.start();
            t2.start();
            t3.start();
            //Dodaj implementację

        }

        public void toConsole() {
            Collections.sort(toConsole);
            toConsole.forEach((n)->System.out.println(n));
        }

        public void main( String[] args )
        {
            Main main = new Main();
            main.startThreads();
            main.toConsole();
        }
    }
}
