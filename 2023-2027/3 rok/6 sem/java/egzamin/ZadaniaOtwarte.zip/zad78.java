public class zad78 {
    /*
    Uzupełnij implementację stałych wyliczeniowych dla klasy reprezentującej pory roku
    pod komentarzem "Dodaj implementację".

    Stałe zdefiniuj wielkimi literami jako odpowiedniki angielskie dla: wiosna, lato, jesień, zima.
     */
    enum EnSeasons{
        //***Dodaj implementację***

    }
    public class Main {




        public void printToConsole() {
            for(EnSeasons et:EnSeasons.values())
                System.out.println(et.name().concat(", ").toString());
        }
        public static void main(String[] args) {
            Main main = new Main();
            main.printToConsole();
            System.out.println(EnSeasons.values().length);
        }
    }
}
