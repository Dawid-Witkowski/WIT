import java.util.function.BinaryOperator;
public class zad82 {
    /*
    Uzupełnij implementację metody concatenate pod komentarzem "Dodaj implementację".

    Implementacja ma być wykonana z użyciem wyrażenia lambda i ma polegać na
    przypisaniu ciała metodzie apply z interfejsu funkcyjnego BinaryOperator.
    Wyrażenie lambda ma wykonywać konkatenacji pierwszego parametru ze spacją oraz z drugim parametrem,
    pod warunkiem że oba parametry nie są null. W przypadku przekazania wartości null całe wyrażenie ma zwrócić null,
    niezależnie od tego który parametr miał przekazany null.
     */
    public class Main {
        protected BinaryOperator<String> fullName = null;
        public void concatenate() {
            //Dodaj implementację

        }
        public void main(String[] args) {
            Main main = new Main();
            main.concatenate();
            main.printToConsole("Jan", "Kowalski");
            main.printToConsole("Jan", "Nowak");
            main.printToConsole("Janina", "Nowakowska");
            main.printToConsole("Janina", null);
            main.printToConsole(null, "Nowakowska");
            main.printToConsole(null, null);
        }
        public void printToConsole(String firstName, String lastName) {
            System.out.println(fullName.apply(firstName, lastName));
        }
    }
}
