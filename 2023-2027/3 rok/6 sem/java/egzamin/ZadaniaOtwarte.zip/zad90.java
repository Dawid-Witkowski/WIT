import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
public class zad90 {
    /*
    Zmodyfikuj deklarację klasy "ArrayIntMultiply" oraz dodaj wymaganą implementację wewnątrz tej klasy pod komentarzem
    "Dodaj implementację". Należy dopisać kod aby klasa "ArrayIntMultiply"
    mogła być użyta do wymnażania elementów tablicy typu "long".
    Klasa musi być kompatybilna z kodem w metodzie "startProcessing".
     */
    public class Main {
        //Dodaj implementację
        public class ArrayIntMultiply {

        }
        public void startProcessing() {
            long arr[] = new long[21];
            arr = new long[] {30, 36, 69, 34, 19, 30, 60, 96, 28, 16, 94, 39, 72, 25, 48, 80, 34, 18, 43, 27, 19};

            ExecutorService es = Executors.newFixedThreadPool(3);
            Future<Long> subResult1, subResult2, subResult3, resultAll;
            subResult1 = es.submit(new ArrayIntMultiply(Arrays.copyOf(arr, 7)));
            subResult2 = es.submit(new ArrayIntMultiply(Arrays.copyOfRange(arr, 7, 14)));
            subResult3 = es.submit(new ArrayIntMultiply(Arrays.copyOfRange(arr, 14, 21)));
            resultAll = es.submit(new ArrayIntMultiply(arr));
            try {
                System.out.println("subResult1=" + subResult1.get());
                System.out.println("subResult2=" + subResult2.get());
                System.out.println("subResult3=" + subResult3.get());
                System.out.println("resultAll=" + resultAll.get());
                System.out.println("check=" + subResult1.get()*subResult2.get()*subResult3.get());
            } catch (InterruptedException | ExecutionException e) {
                System.out.println(e);
            }
            es.shutdown();
        }

        public void main( String[] args )
        {
            Main main = new Main();
            main.startProcessing();

        }
    }
}
