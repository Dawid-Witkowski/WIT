import java.util.LinkedHashSet;
import java.util.Set;
public class zad88 {
    /*
    Uzupełnij implementację metody "addColor" pod komentarzem "Dodaj implementację".

    Metoda ma dodawać przekazany w parametrze kolor do zbioru kolorów (zmienna setColors) pod warunkiem,
    że jest on poprawnie zdefiniowany. Poprawnie w tym kontekście oznacza, że jego wartość nie jest "null" oraz
    nie jest pustym łańcuchem znaków lub zawierającym tylko "same spacje". Jeśli kolor nie jest poprawnie zdefiniowany
    to metoda ma nie robić nic.

     */
    public class Main {
        private Set<String> setColors = new LinkedHashSet<>();

        public void addColor(String color) {
            //***Dodaj implementację***
        }

        public Set<String> getSetColors() {
            return setColors;
        }

        public void main(String[] args) {
            Main main = new Main();
            main.addColor(null);
            main.addColor("");
            main.addColor(" ");
            main.addColor("red");
            main.addColor("    ");
            main.addColor("green");
            main.addColor("\n");
            main.addColor("\r");
            System.out.println(main.getSetColors());
        }

    }
}
