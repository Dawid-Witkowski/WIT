import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class zad73 {
    /*
    Uzupełnij implementację metody filterElements pod komentarzem "Dodaj implementację".

    Metoda ma zwrócić strumień utworzony z co 4 elementu listy itemsList licząc od drugiego elementu listy (indeks 1).
    Dodatkowo element musi spełniać warunek,
    że indeks elementu na liście jest większy lub równy 80 (koniunkcja 2 warunków).
     */
    public class Main {
        protected List<String> itemsList = null;
        public Main() {
            itemsList = new ArrayList<>();
            for(int i=0;i<100;i++)
                itemsList.add("Ala_".concat(String.valueOf(i+1)));

        }
        public Stream<String> filterElements() {
            //Dodaj implementację
        }
        public void main(String[] args) {
            Main main = new Main();
            main.filterElements().forEach((n)->System.out.println(n));;
        }
    }
}
