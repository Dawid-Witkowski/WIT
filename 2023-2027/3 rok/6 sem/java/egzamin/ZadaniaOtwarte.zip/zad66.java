public class zad66 {
    /*
     Uzupełnij implementację dwóch konstruktorów: klasy "Question3Base" oraz "Question3"
     pod komentarzem "Dodaj implementację" (w 2 miejscach). Konstruktor "Question3Base"
     ma inicjalizować zmienne dotyczące imienia i nazwiska. Natomiast konstruktor "Question3"

    ma wywoływać konstruktor z klasy bazowej, a następnie zainicjalizować zmienne "age" oraz "education".
    Tablica ma otrzymać rozmiar dziesięć.
     */
    public class Main {
        public Question3 q3 = null;

        public class Question3Base{
            private String firstName=null;
            private String lastName=null;
            public Question3Base(String firstName,String lastName) {
                //***Dodaj implementację***

            }
            public String getFirstName() {
                return firstName;
            }
            public String getLastName() {
                return lastName;
            }
        }
        public class Question3 extends Question3Base{

            private int age;
            private String[] education = null;

            public Question3(int age, String firstName,String lastName) {
                //***Dodaj implementację***


            }

            public int getAge() {
                return age;
            }

            public String[] getEducation() {
                return education;
            }
        }

        public Main() {
            q3 = new Question3(30,"Ola","Myszkowska");
        }

        public void main(String[] args) {
            Main main = new Main();
            System.out.println(main.q3.getAge());
            System.out.println(main.q3.getFirstName());
            System.out.println(main.q3.getLastName());
            System.out.println(main.q3.getEducation().length);

        }
    }
}
