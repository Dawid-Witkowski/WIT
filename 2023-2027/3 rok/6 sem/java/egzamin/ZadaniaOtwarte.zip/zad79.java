import java.util.LinkedHashMap;
import java.util.Map;
public class zad79 {
    /*
    Uzupełnij implementację metody "addToMap" pod komentarzem "Dodaj implementację".
    Metoda ma dodawać do mapy "mapCars" pary które składają się z kluczy różnych od null oraz
    różnych od pustego ciągu znaków. Ponadto wartość dodawana do mapy musi być liczbą dodatnią.
    W przypadku niespełnienia warunku metoda ma nic nie robić.
     */
    public class Main {
        private Map<String,Integer> mapCars = null;

        public Main() {
            this.mapCars = new LinkedHashMap<>();
        }

        public void addToMap(String car, int maxSpeed) {
            // Dodaj implementację
        }

        public void toConsole() {
            this.mapCars.forEach((n,m)-> System.out.println(n.concat(":").concat(Integer.toString(m))));
        }

        public void main(String[] args) {
            Main main = new Main();
            main.addToMap("Porsche",250);
            main.addToMap("",300);
            main.addToMap("Fiat",-300);
            main.addToMap(null,30);
            main.addToMap("Audi",240);
            main.toConsole();
        }
    }

}
