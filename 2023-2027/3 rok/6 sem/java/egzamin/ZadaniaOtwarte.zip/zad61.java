import java.util.ArrayList;
import java.util.List;
public class zad61 {
    /*
    Uzupełnij implementację metody "listToString" pod komentarzem "Dodaj implementację".
    Metoda ma zbudować łańcuch znaków składający się z kolejnych liczb stanowiących elementy listy
    oddzielonych znakiem "+" (bez spacji przed i po).
    Następnie na końcu tak zbudowanego łańcucha znaków ma być doklejone "=?" (również bez spacji przed i po).
    Zatem wynik działania metody to 1 wiersz tekstu.

    UWAGA: nie można modyfikować żadnych innych elementów klasy.

            UWAGA2: Kod musi być zgodny z JAVA 1.8

    UWAGA3: Kod należy edytować w Insperze (nie kopiować do inspery).

    UWAGA4: Po zakończeniu wpisywania treści odpowiedzi należy skompilować kod (przycisk u dołu "KOD TESTU")
    */

    public class Main {
        private List<Integer> lstNumbers = new ArrayList<Integer>();

        public String listToString() {
            StringBuilder sb = new StringBuilder();
            //***Dodaj implementację***
            return sb.toString();
        }
        public List<Integer> getLstNumbers() {
            return lstNumbers;
        }

        public void main(String[] args) {
            Main main = new Main();
            main.getLstNumbers().add(123);
            main.getLstNumbers().add(3);
            main.getLstNumbers().add(1);
            main.getLstNumbers().add(2);
            System.out.println(main.listToString());
        }
    }
}
