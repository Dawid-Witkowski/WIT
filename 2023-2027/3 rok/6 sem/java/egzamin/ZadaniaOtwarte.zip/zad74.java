import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;
public class zad74 {
    /*
    Uzupełnij implementację metody toStringBuilder pod komentarzem "Dodaj implementację".

    Metoda ma zwracać obiekt StringBuildera zawierający elementy mapy w postaci: klucz:wartość.
    Pomiędzy kluczem i wartością ma być jedynie ciąg znaków ":" (bez spacji),
    a na końcu każdego wiersza znak końca linii. Wartość która jest datą, ma być wypisana w formacie dzień.miesiąc.
    rok (separator to kropka, dzień 2 cyfry, miesiąc 2 cyfry, rok 4 cyfry)
     */
    public class Main {
        protected Map<String,LocalDate> mapDates = null;
        public Main() {
            mapDates = new TreeMap<>();
            mapDates.put("Ela", LocalDate.parse("1999-11-21"));
            mapDates.put("Olaf", LocalDate.parse("1996-04-10"));
            mapDates.put("Ala", LocalDate.parse("1998-12-27"));
            mapDates.put("Jan", LocalDate.parse("1997-07-12"));
        }
        public StringBuilder toStringBuilder() {
            StringBuilder sb = new StringBuilder();
            //Dodaj implementację

            return sb;
        }
        public  void main(String[] args) {
            Main main = new Main();
            System.out.println(main.toStringBuilder().toString());
        }
    }
}
