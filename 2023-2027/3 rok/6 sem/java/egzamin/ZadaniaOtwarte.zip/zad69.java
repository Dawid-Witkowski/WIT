public class zad69 {
    /*
    Uzupełnij implementację konstruktora klasy "Question1" pod komentarzem "Dodaj implementację".
    Należy zaimplementować konstruktor w taki sposób aby wszystkie zmienne składowe klasy były zainicjalizowane.
    Tablica ma otrzymać rozmiar zero.
     */
    public class Main {
        public Question1 q1 = null;
        public class Question1{
            private int age;
            private String firstName=null;
            private String lastName=null;
            private String[] education = null;

            public Question1(int age,String firstName,String lastName) {
                //***Dodaj implementację***

            }
            public int getAge() {
                return age;
            }
            public String getFirstName() {
                return firstName;
            }
            public String getLastName() {
                return lastName;
            }
            public String[] getEducation() {
                return education;
            }
        }

        public Main() {
            q1 = new Question1(21,"Ala","Kotarska");
        }

        public void main(String[] args) {
            Main main = new Main();
            System.out.println(main.q1.getAge());
            System.out.println(main.q1.getFirstName());
            System.out.println(main.q1.getLastName());
            System.out.println(main.q1.getEducation().length);

        }
    }
}
